package com.MedApp.historico2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Historico2Application {

	public static void main(String[] args) {
		SpringApplication.run(Historico2Application.class, args);
	}

}
