package com.MedApp.historico2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Historico2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
